PRESTIGE DIGITOOLS
CONTRACTOR ESTIMATE & PROPOSAL STUDIO PRO
Version 1.0 | SKU PDT-ESTPROP-001

WHAT THIS IS
A self-contained offline browser application for building contractor estimates from real job costs and producing a clean customer-facing proposal from the same project data.

WHAT IS INCLUDED
- index.html — the complete application
- README.txt — setup, workflow, calculation notes and QA guidance
- LICENSE.txt — internal business-use license

HOW TO USE
1. Extract the ZIP to a normal folder.
2. Open index.html in a current Chrome, Edge, Firefox or Safari browser.
3. Enter customer/project information and scope.
4. Replace the starter cost rows with actual project-specific quantities and costs.
5. Mark taxable rows according to your own local tax treatment.
6. Set tax %, overhead recovery %, target gross margin %, and deposit %.
7. Review the internal economics dashboard.
8. Review the customer proposal preview.
9. Use Print / Save Proposal PDF for customer delivery.
10. Use Save for browser-local storage and Backup JSON for a portable project backup.

CORE PRICING MATH
Direct Job Cost = sum(quantity × unit cost)
Tax = taxable direct cost × tax rate
Overhead Recovery = (direct job cost + tax) × overhead rate
Cost Basis = direct job cost + tax + overhead recovery
Selling Price = cost basis ÷ (1 − target margin)
Gross Profit = selling price − cost basis
Deposit = selling price × deposit %
Balance = selling price − deposit

IMPORTANT
Margin is not markup. A 20% target margin means dividing cost basis by 0.80.
Overhead recovery is applied once. Do not manually add the same overhead again inside line-item costs unless that is intentionally how your accounting system is structured.

CUSTOMER PROPOSAL
The proposal intentionally hides internal unit costs, tax base, overhead recovery, margin, and profit. It shows the project scope, total investment, deposit and balance, plus proposal notes and exclusions.

DATA & PRIVACY
The application runs locally in the browser. Save uses localStorage on that device/browser. Backup JSON creates a portable file you control. Clearing browser storage can remove saved local data, so use Backup JSON for important estimates.

BUSINESS / LEGAL NOTICE
This is a contractor business-planning and proposal productivity tool. It does not provide legal, tax, accounting, engineering, insurance, code-compliance, financial or professional advice. Review job-specific pricing, contracts, tax treatment, licensing, permit requirements, scope, warranty obligations and calculations before relying on outputs.

SUPPORT
Jason@PrestigeRemodelingWI.com
920-242-0969
PrestigeRemodelingWI.com
