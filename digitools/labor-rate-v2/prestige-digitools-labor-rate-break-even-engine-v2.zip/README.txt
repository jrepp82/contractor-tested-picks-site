PRESTIGE DIGITOOLS
CONTRACTOR LABOR RATE & BREAK-EVEN ENGINE PRO — VERSION 2.0

SKU: PDT-LABORRATE-001

1. WHAT THIS TOOL DOES
This browser-based business-planning tool calculates:
- loaded regular labor cost
- overtime payroll cost
- annual overhead recovery
- entered and effective billable capacity
- same-week fatigue / productivity loss
- recovery drag from recent overtime or heavy workload
- break-even rate before productivity adjustments
- break-even rate after fatigue
- break-even rate after fatigue + recovery drag
- target selling rate at a selected profit margin
- equivalent markup
- weekly and annual revenue targets
- projected annual operating profit
- billable-hour sensitivity

2. HOW TO OPEN
1. Extract this ZIP to a normal folder.
2. Open index.html in Chrome, Edge, Firefox, or Safari.
3. No installation, account, or internet connection is required for the calculator.

3. FIRST-TIME SETUP
Replace the demo values with your real business assumptions:
- crew size
- regular paid hours per person per week
- entered billable hours per person per week
- working weeks per year
- base wage
- payroll tax %
- workers' compensation %
- benefits $ per paid hour
- other labor burden $ per paid hour
- overtime hours and overtime multiplier
- annual overhead line items
- fatigue / productivity loss %
- recovery drag %
- target profit margin %

4. PRODUCTIVITY MODEL
OVERTIME is a cost-side variable. Entered OT hours increase annual payroll using the OT multiplier. Paid overtime does not automatically increase billable capacity.

FATIGUE / PRODUCTIVITY LOSS is a capacity-side variable. It reduces entered billable capacity for the current period.

RECOVERY DRAG is also a capacity-side variable. It represents productivity loss carried into the current week from recent overtime, long days, unusually demanding physical work, or similar workload conditions.

The engine applies:
Effective Billable = Entered Billable × (1 − Fatigue Rate) × (1 − Recovery Drag Rate)

Recovery Drag does not add payroll cost or overhead. Use 0% when the crew is fully recovered. Keep the assumption realistic. It is a planning input, not a medical measurement.

V2 does NOT automatically derive Recovery Drag from overtime hours and does not use medical-style recovery curves.

5. MARGIN VS MARKUP
A profit margin is not the same as markup.

Selling Rate = Break-Even ÷ (1 − Target Margin)

Example:
20% margin = 25% markup.
50% margin = 100% markup.

6. DEMO BASELINE
The included demo uses:
- 2-person crew
- 40 regular paid hours/person/week
- 30 entered billable hours/person/week
- 48 working weeks
- $32.00 base wage
- 10% payroll tax
- 8% workers' compensation
- $3.00 benefits/hour
- $1.50 other burden/hour
- $63,600 annual overhead
- 20% target margin
- 0 OT, 0 fatigue, 0 recovery drag

Expected baseline:
Break-even ≈ $78.43/hour
Target selling rate ≈ $98.04/hour

7. RECOVERY DRAG EXAMPLES
With a $98.04/hour baseline target and no other changes:
- 6% recovery drag → ≈ $104.30/hour
- 12% recovery drag → ≈ $111.41/hour
- 15% recovery drag → ≈ $115.34/hour

With 30 entered billable hours, 10% fatigue and 6% recovery:
30 × 0.90 × 0.94 = 25.38 effective billable hours/person/week.

8. SAVE / BACKUP / RESTORE
- Save Scenario stores the current inputs in this browser's localStorage.
- Backup JSON downloads a portable scenario backup.
- Restore JSON reloads a valid Prestige backup file.
- Reset Demo returns every input to the included demo scenario.

9. PRINT / PDF
Use Print / PDF for a clean rate-audit output. The editable input panel is intentionally hidden in print so the result reads like an audit summary.

10. WARNINGS
- Recovery warning begins at 5%.
- High recovery warning begins at 12%.
- Combined strain warning appears when fatigue is at least 10% and recovery drag is at least 5%.
- The tool also flags active OT as payroll cost that does not automatically create billable capacity.

11. DATA & PRIVACY
Core calculations run locally in the browser. The tool does not require a cloud account.

12. LICENSE
Single-purchaser / single-business internal-use license. No resale, redistribution, sharing, white-labeling, sublicensing, or public hosting. See LICENSE.txt.

13. SUPPORT
Jason@PrestigeRemodelingWI.com

14. DISCLAIMER
Business-planning software only. It is not accounting, payroll, tax, legal, medical, insurance, engineering, or financial advice. Productivity factors are user-controlled planning assumptions. Verify inputs and decisions with qualified professionals where appropriate. No guarantee of revenue, profit, utilization, margin, or other business result.
